#LIBRERIAS
import turtle
import random
from time import * 

#SOLICITUD DE DATOS
nom = input("Ingresa su nombre: ")
try: #CONDIDICION POR SI EL DATO INGRESADO EN LA EDAD  ES INVALIDO
    an = int(input("Ingrese su edad: "))
except:
    print("Error al ingresar la edad por favor ingrese solo numero: ")
    an = int(input("Ingrese su edad: "))
fc = input("Ingrese su color favorito: ")

def limpiar(): #LIMPIA LA PANTALLA DEL TURTLE
    sleep(15)
    turtle.clearscreen()


def marcos(): #MARGEN CON DISEÑO POLIGONAL 
    turtle.hideturtle()
    turtle.speed(50)
    turtle.penup()
    turtle.setpos(-525,325) 
    turtle.pendown()
    turtle.width(3)
    for i in range(2):
        turtle.forward(1050)
        turtle.right(90)
        turtle.forward(650)
        turtle.right(90)
    turtle.penup()
    turtle.setpos(-525,325) 
    turtle.pendown()
    for i in range(2):
        turtle.forward(1050)
        turtle.right(90)
        turtle.forward(75)
        turtle.right(90)
    turtle.penup()
    turtle.setpos(-525,-150) 
    turtle.pendown()
    for i in range(2):
        turtle.forward(1050)
        turtle.right(90)
        turtle.forward(175)
        turtle.right(90)
        turtle.speed(10)
    turtle.penup()
    turtle.goto(0,275)
    turtle.pendown()
    turtle.write(f"La estrella curiosa la aventura de {nom}", False, "center", ("comic sans", 20))

#SECUENCIAS DE LA HISTORIA


def secuencia1():
    turtle.begin_fill()
    t = turtle.Pen()
    turtle.speed(0)
    turtle.setup(1200, 800)
    turtle.bgcolor('white')
    turtle.clear()
    turtle.reset()
   
    turtle.fillcolor("white")
    marcos()
    def cielo():
       
        # Función para dibujar una estrella
        def draw_star(size, color):
            turtle.color(color)
            turtle.begin_fill()
            for _ in range(5):
                turtle.forward(size)
                turtle.right(144)
            turtle.end_fill()

        # Función para dibujar un rectángulo con estrellas dentro
        def draw_rect_with_stars(width, height, num_stars, star_size):
            turtle.penup()
            turtle.color('black')
            turtle.goto(-width / 2, height / 2)
            turtle.pendown()
            for _ in range(2):
                turtle.forward(width)
                turtle.right(90)
                turtle.forward(height)
                turtle.right(90)

            for _ in range(num_stars):
                x = random.randint(-width // 2 + 10, width // 2 - 10)
                y = random.randint(-height // 2 + 10, height // 2 - 10)
                color = random.choice(["orange", "yellow"])
                turtle.penup()
                turtle.goto(x, y)
                turtle.pendown()
                draw_star(star_size, color)

        # Llamada a la función para dibujar el rectángulo con estrellas
        draw_rect_with_stars(1050, 300, 100, 20)
    def estrella():
        turtle.speed(0)
        turtle.color("yellow")
        turtle.begin_fill()

        # Dibujar la estrella completamente rellena
        for _ in range(5):
            turtle.forward(200)  # Longitud de los lados de la estrella
            turtle.right(144)

        # Rellenar el centro de la estrella
        turtle.goto(-50, -50)
        turtle.end_fill()
        turtle.hideturtle()

    
    turtle.end_fill()
    
    
    
    turtle.penup()
    turtle.goto(0,-275)
    turtle.pendown()
    turtle.speed(10)
    turtle.color('black')
    turtle.write(f"En el cielo nocturno, brillaba una estrella llamada {nom}.\n{nom} siempre había sido una estrella muy curiosa, y una noche decidió bajar a la Tierra para explorar. ", align='center',font=('Comic sans', 16, 'normal'))
    cielo()
    estrella()
    limpiar()
       
def secuencia2():
    
    t = turtle.Pen()
    turtle.speed(0)
    turtle.setup(1200, 800)
    turtle.bgcolor('white')
    turtle.bgcolor("white")
    marcos()
    
    def hada1():
        # Configuración inicial
        turtle.speed(0)
        turtle.color("purple")
        turtle.pensize(2)

        # Cuerpo del hada
        turtle.begin_fill()
        turtle.penup()
        turtle.goto(0,-20)
        turtle.pendown()
        turtle.circle(50)
        turtle.end_fill()
        

        # Cabeza del hada
        turtle.color("lightpink")
        turtle.penup()
        turtle.goto(0, 50)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(30)
        turtle.end_fill()

        # Alas del hada
        turtle.color("lightblue")
        turtle.penup()
        turtle.goto(0, 80)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, -180)
        turtle.circle(20, 180)
        turtle.end_fill()

        # Otra ala del hada
        turtle.penup()
        turtle.goto(0, 80)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, 180)
        turtle.circle(20, -180)
        turtle.end_fill()

        # Varita mágica
        turtle.color("yellow")
        turtle.penup()
        turtle.goto(30, 50)
        turtle.pendown()
        turtle.setheading(-70)
        turtle.forward(40)

        # Estrella en la varita
        turtle.penup()
        turtle.goto(35, 50)
        turtle.pendown()
        turtle.color("yellow")
        turtle.begin_fill()
        for _ in range(5):
            turtle.forward(10)
            turtle.right(144)
        turtle.end_fill()

        # Ocultar Turtle y mantener la ventana abierta
        turtle.hideturtle()
    def hada2():
        # Configuración inicial
        turtle.speed(0)
        turtle.color("green")
        turtle.pensize(2)

        # Cuerpo del hada
        turtle.begin_fill()
        turtle.penup()
        turtle.goto(50,-40)
        turtle.pendown()
        turtle.circle(50)
        turtle.end_fill()
        

        # Cabeza del hada
        turtle.color("lightpink")
        turtle.penup()
        turtle.goto(70, 30)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(30)
        turtle.end_fill()

        # Alas del hada
        turtle.color("lightblue")
        turtle.penup()
        turtle.goto(70, 60)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, -180)
        turtle.circle(20, 180)
        turtle.end_fill()

        # Otra ala del hada
        turtle.penup()
        turtle.goto(70, 60)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, 180)
        turtle.circle(20, -180)
        turtle.end_fill()

        # Varita mágica
        turtle.color("yellow")
        turtle.penup()
        turtle.goto(120, -10)
        turtle.pendown()
        turtle.setheading(-70)
        turtle.forward(40)

        # Estrella en la varita
        turtle.penup()
        turtle.goto(120, 0)
        turtle.pendown()
        turtle.color("yellow")
        turtle.begin_fill()
        for _ in range(5):
            turtle.forward(10)
            turtle.right(144)
        turtle.end_fill()

        # Ocultar Turtle y mantener la ventana abierta
        turtle.hideturtle()
    def hada3():
        # Configuración inicial
        turtle.speed(0)
        turtle.color("red")
        turtle.pensize(2)

        # Cuerpo del hada
        turtle.begin_fill()
        turtle.penup()
        turtle.goto(-140,-40)
        turtle.pendown()
        turtle.circle(50)
        turtle.end_fill()
        

        # Cabeza del hada
        turtle.color("lightpink")
        turtle.penup()
        turtle.goto(-140, 30)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(30)
        turtle.end_fill()

        # Alas del hada
        turtle.color("lightblue")
        turtle.penup()
        turtle.goto(-140, 60)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, -180)
        turtle.circle(20, 180)
        turtle.end_fill()

        # Otra ala del hada
        turtle.penup()
        turtle.goto(-140, 60)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, 180)
        turtle.circle(20, -180)
        turtle.end_fill()

        # Varita mágica
        turtle.color("yellow")
        turtle.penup()
        turtle.goto(-100, -10)
        turtle.pendown()
        turtle.setheading(-70)
        turtle.forward(40)

        # Estrella en la varita
        turtle.penup()
        turtle.goto(-100, 0)
        turtle.pendown()
        turtle.color("yellow")
        turtle.begin_fill()
        for _ in range(5):
            turtle.forward(10)
            turtle.right(144)
        turtle.end_fill()

        # Ocultar Turtle y mantener la ventana abierta
        turtle.hideturtle()
    def sol():
        t = turtle.Turtle()
        t.speed(0)
        t.color("yellow")
        t.penup()
        t.goto(300, 150)  # Posición del sol en la esquina superior derecha
        t.pendown()
        t.begin_fill()
        for _ in range(36):
            t.forward(150)
            t.right(170)
        t.end_fill()
        t.hideturtle()
    
    sol()
    hada1()
    hada2()
    hada3()
    turtle.penup()
    turtle.goto(0,-275)
    turtle.pendown()
    turtle.speed(10)
    turtle.color('black')
    turtle.write(f"Cuando llegó a la Tierra, {nom} descubrió un bosque mágico lleno de árboles luminosos\ny hadas que bailaban bajo la luz de la luna.{nom} se sintió maravillada por la bellea del lugar.", align='center', font=('Arial', 16, 'normal'))

    limpiar()
    
def secuencia3():
    turtle.begin_fill()
    t = turtle.Pen()
    turtle.speed(0)
    turtle.setup(1200, 800)
    turtle.bgcolor('white')
    turtle.clear()
    turtle.reset()
    turtle.fillcolor("white")
    marcos()
    
    def sol():
        t = turtle.Turtle()
        t.speed(0)
        t.color("gray")
        t.penup()
        t.goto(0, 50)  # Posición del sol en la esquina superior derecha
        t.pendown()
        t.begin_fill()
        for _ in range(36):
            t.forward(150)
            t.right(170)
        t.end_fill()
        t.hideturtle()
    
    sol()
    turtle.penup()
    turtle.goto(0,-275)
    turtle.pendown()
    turtle.speed(10)
    turtle.write(f"Pero pronto, {nom} se dio cuenta de que su luz estaba desapareciendo. Al estar lejos del cielo,\nsu brillo se apagaba poco a poco. {nom} sintió miedo de desaparecer por completo. ", align='center', font=('Arial', 16, 'normal'))
  
    limpiar()

def secuencia4():
    t = turtle.Pen()
    turtle.speed(0)
    turtle.setup(1200, 800)
    turtle.bgcolor('white')
    turtle.reset()
    turtle.bgcolor("white")
    marcos()
    def hada1():
        # Configuración inicial
        turtle.speed(0)
        turtle.color("purple")
        turtle.pensize(2)

        # Cuerpo del hada
        turtle.begin_fill()
        turtle.penup()
        turtle.goto(0,-20)
        turtle.pendown()
        turtle.circle(50)
        turtle.end_fill()
        

        # Cabeza del hada
        turtle.color("lightpink")
        turtle.penup()
        turtle.goto(0, 50)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(30)
        turtle.end_fill()

        # Alas del hada
        turtle.color("lightblue")
        turtle.penup()
        turtle.goto(0, 80)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, -180)
        turtle.circle(20, 180)
        turtle.end_fill()

        # Otra ala del hada
        turtle.penup()
        turtle.goto(0, 80)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, 180)
        turtle.circle(20, -180)
        turtle.end_fill()

        # Varita mágica
        turtle.color("yellow")
        turtle.penup()
        turtle.goto(30, 50)
        turtle.pendown()
        turtle.setheading(-70)
        turtle.forward(40)

        # Estrella en la varita
        turtle.penup()
        turtle.goto(35, 50)
        turtle.pendown()
        turtle.color("yellow")
        turtle.begin_fill()
        for _ in range(5):
            turtle.forward(10)
            turtle.right(144)
        turtle.end_fill()

        # Ocultar Turtle y mantener la ventana abierta
        turtle.hideturtle()
    def hada2():
        # Configuración inicial
        turtle.speed(0)
        turtle.color("green")
        turtle.pensize(2)

        # Cuerpo del hada
        turtle.begin_fill()
        turtle.penup()
        turtle.goto(50,-40)
        turtle.pendown()
        turtle.circle(50)
        turtle.end_fill()
        

        # Cabeza del hada
        turtle.color("lightpink")
        turtle.penup()
        turtle.goto(70, 30)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(30)
        turtle.end_fill()

        # Alas del hada
        turtle.color("lightblue")
        turtle.penup()
        turtle.goto(70, 60)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, -180)
        turtle.circle(20, 180)
        turtle.end_fill()

        # Otra ala del hada
        turtle.penup()
        turtle.goto(70, 60)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, 180)
        turtle.circle(20, -180)
        turtle.end_fill()

        # Varita mágica
        turtle.color("yellow")
        turtle.penup()
        turtle.goto(120, -10)
        turtle.pendown()
        turtle.setheading(-70)
        turtle.forward(40)

        # Estrella en la varita
        turtle.penup()
        turtle.goto(120, 0)
        turtle.pendown()
        turtle.color("yellow")
        turtle.begin_fill()
        for _ in range(5):
            turtle.forward(10)
            turtle.right(144)
        turtle.end_fill()

        # Ocultar Turtle y mantener la ventana abierta
        turtle.hideturtle()
    def hada3():
        # Configuración inicial
        turtle.speed(0)
        turtle.color("red")
        turtle.pensize(2)

        # Cuerpo del hada
        turtle.begin_fill()
        turtle.penup()
        turtle.goto(-140,-40)
        turtle.pendown()
        turtle.circle(50)
        turtle.end_fill()
        

        # Cabeza del hada
        turtle.color("lightpink")
        turtle.penup()
        turtle.goto(-140, 30)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(30)
        turtle.end_fill()

        # Alas del hada
        turtle.color("lightblue")
        turtle.penup()
        turtle.goto(-140, 60)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, -180)
        turtle.circle(20, 180)
        turtle.end_fill()

        # Otra ala del hada
        turtle.penup()
        turtle.goto(-140, 60)
        turtle.pendown()
        turtle.begin_fill()
        turtle.circle(20, 180)
        turtle.circle(20, -180)
        turtle.end_fill()

        # Varita mágica
        turtle.color("yellow")
        turtle.penup()
        turtle.goto(-100, -10)
        turtle.pendown()
        turtle.setheading(-70)
        turtle.forward(40)

        # Estrella en la varita
        turtle.penup()
        turtle.goto(-100, 0)
        turtle.pendown()
        turtle.color("yellow")
        turtle.begin_fill()
        for _ in range(5):
            turtle.forward(10)
            turtle.right(144)
        turtle.end_fill()

        # Ocultar Turtle y mantener la ventana abierta
        turtle.hideturtle()
    def sol():
        t = turtle.Turtle()
        t.speed(0)
        t.color("yellow")
        t.penup()
        t.goto(-300, 0)  # Posición del sol en la esquina superior derecha
        t.pendown()
        t.begin_fill()
        for _ in range(36):
            t.forward(150)
            t.right(170)
        t.end_fill()
        t.hideturtle()
    
    def corazon():
        def curve():
            for i in range(200):
                turtle.right(1)
                turtle.forward(1)

        def heart():
            turtle.fillcolor('red')
            turtle.begin_fill()
            turtle.left(140)
            turtle.forward(113)
            curve()
            turtle.left(120)
            curve()
            turtle.forward(112)
            turtle.end_fill()
        
        turtle.hideturtle()
        heart()
        
    hada1()
    hada2()
    hada3()
    sol()
    corazon()
    
    turtle.penup()
    turtle.goto(0,-275)
    turtle.pendown()
    turtle.speed(10)
    turtle.color('black')
    turtle.write(f"Entonces, las hadas del bosque se acercaron a {nom} y le recordaron que su verdadera luz estaba en su interior,\nen su corazón brillante y valiente. Con esa luz interior, {nom} volvió a brillar con fuerza.", align='center', font=('Arial', 16, 'normal'))
    limpiar()

def secuencia5():
    t = turtle.Pen()
    turtle.speed(0)
    turtle.setup(1200, 800)
    turtle.bgcolor('white')
    turtle.reset()
    turtle.bgcolor("white")
    marcos()
    def cielo():
           
        # Función para dibujar una estrella
        def draw_star(size, color):
            turtle.color(color)
            turtle.begin_fill()
            for _ in range(5):
                turtle.forward(size)
                turtle.right(144)
            turtle.end_fill()

        # Función para dibujar un rectángulo con estrellas dentro
        def draw_rect_with_stars(width, height, num_stars, star_size):
            turtle.penup()
            turtle.color('black')
            turtle.goto(-width / 2, height / 2)
            turtle.pendown()
            for _ in range(2):
                turtle.forward(width)
                turtle.right(90)
                turtle.forward(height)
                turtle.right(90)

            for _ in range(num_stars):
                x = random.randint(-width // 2 + 10, width // 2 - 10)
                y = random.randint(-height // 2 + 10, height // 2 - 10)
                color = random.choice(["orange", "yellow"])
                turtle.penup()
                turtle.goto(x, y)
                turtle.pendown()
                draw_star(star_size, color)

        # Llamada a la función para dibujar el rectángulo con estrellas
        draw_rect_with_stars(1050, 300, 100, 20)
   
    def sol():
        t = turtle.Turtle()
        t.speed(0)
        t.color("orange")
        t.penup()
        t.goto(-300, 0)  # Posición del sol en la esquina superior derecha
        t.pendown()
        t.begin_fill()
        for _ in range(36):
            t.forward(150)
            t.right(170)
        t.end_fill()
        t.hideturtle()
    
    cielo()
    sol()
    
    turtle.penup()
    turtle.goto(0, -275)
    turtle.pendown()
    turtle.speed(10)
    turtle.color('black')
    turtle.write(f"Al amanecer, {nom} regresó al cielo, agradecido por la aventura y por\nhaber descubierto que su luz era más fuerte de lo que creía.", align='center', font=('Arial', 16, 'normal'))
    limpiar()


#MENU       
menu = """
Menú:
1. Secuencia 1
2. Secuencia 2
3. Secuencia 3
4. Secuencia 4
5. Secuencia 5
6. Salir
"""

#ACCIONES DEL MENU
bandera = True
while bandera:
    print(menu)
    opcion = input("Seleccione una secuencia (1-5) o Salir (6): ")
    if opcion == "1" or opcion.lower()=="secuencia 1":
        secuencia1()
    elif opcion == "2" or opcion.lower()=="secuencia 2":
        secuencia2()
    elif opcion == "3" or opcion.lower()=="secuencia 3":
        secuencia3()
    elif opcion == "4" or opcion.lower()=="secuencia 4":
        secuencia4()
    elif opcion == "5" or opcion.lower()=="secuencia 5":
        secuencia5()
    elif opcion == "6" or opcion.lower()=="salir":
        bandera=False
        break
        
    else:
        print("Opción no válida. Por favor, seleccione una opción válida (1-6).")



# Keep the window open
turtle.done()