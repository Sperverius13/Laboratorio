print("Semana No. 10: Ejercicio 1")

mes = int(input("Ingrese un numero entre 1 y 12:  "))

if mes<1 or mes>12:
    print("Error: Numero erroneo, ingrese un numero dentro del rango de 1 y 12")
else: 
    if mes==1:
        print("Mes: Enero")
    elif mes ==2:
        print("Mes: Febrero")
    elif mes ==3:
        print("Mes: Marzo")
    elif mes ==4:
        print("Mes: Abril")
    elif mes ==5:
        print("Mes: Mayo")
    elif mes ==6:
        print("Mes: Junio")
    elif mes ==7:
        print("Mes: Julio")
    elif mes ==8:
        print("Mes: Agosto")
    elif mes ==9:
        print("Mes: Septiembre")
    elif mes ==10:
        print("Mes: Octubre")
    elif mes ==11:
        print("Mes: Noviembre")
    elif mes ==12:
        print("Mes: Diciembre")