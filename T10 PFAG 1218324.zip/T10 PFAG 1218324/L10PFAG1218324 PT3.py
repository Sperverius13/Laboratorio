print("Semana No. 10: Ejercicio 3")

d = int(input("Ingrese el dia en que nacio: "))
m = int(input("Ingrese el mes en que nacio: "))
a = int(input("Ingrese el año en que nacio: "))

if (m<1 or m>12) or ( d > 0 or d < 31):
    print("Ingrese una fecha valida")
else: 
    if (m == 3 and d>=21) or (m==4 and d<=19): 
        print("Su signo zodiacal es Aries")
    elif (m == 4 and d>=20) or (m==5 and d<=20):
        print("Su signo zodiacal es Tauro")
    elif (m == 5 and d>=21) or (m==6 and d<=20):
        print("Su signo zodiacal es Geminis")
    elif (m == 6 and d>=21) or (m==7 and d<=22):
        print("Su signo zodiacal es Cancer")
    elif (m == 7 and d>=23) or (m==8 and d<=22):
        print("Su signo zodiacal es Leo")
    elif (m == 8 and d>=23) or (m==9 and d<=22):
        print("Su signo zodiacal es Virgo")
    elif (m == 9 and d>=23) or (m==10 and d<=22):
        print("Su signo zodiacal es Libra")
    elif (m == 10 and d>=23) or (m==11 and d<=21):
        print("Su signo zodiacal es Escorpio")
    elif (m == 11 and d>=22) or (m==12 and d<=21):
        print("Su signo zodiacal es Sagitario")
    elif (m == 12 and d>=22) or (m==1 and d<=19):
        print("Su signo zodiacal es Capricornio")
    elif (m == 1 and d>=20) or (m==2 and d<=18):
        print("Su signo zodiacal es Acuario")
    elif (m == 2 and d>=19) or (m==3 and d<=20):
        print("Su signo zodiacal es Pisis")
    else: 
        print("Ingrese una fecha valida")