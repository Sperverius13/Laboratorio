print("Semana No. 10: Ejercicio 2")

a = int(input("Ingrese el valor de a: "))
b = int(input("Ingrese el valor de b: "))
c = int(input("Ingrese el valor de c: "))

if a > b:
    if a > c:
        print("A es el mayor")
    else:
        if a == c: 
            print("A y C son los mayores")
        else:
            print("C es el mayor")
else:
    if a == b:
        if a > c:
            print("A y B son los mayores")
        else: 
            if a == c:
                print("A,B y C tienen el mismo valor")
            else:
                print("C es el mayor")
    else:
        if b > c:
            print("B es el mayor")
        else:
            if b == c:
                print("B y C son los mayores")
            else:
                print("C es el mayor")